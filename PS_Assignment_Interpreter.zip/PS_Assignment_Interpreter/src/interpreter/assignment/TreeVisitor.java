package interpreter.assignment;

import interpreter.tree.DivisionTreeNode;
import interpreter.tree.LeafTreeNode;
import interpreter.tree.SubtractionTreeNode;
import interpreter.tree.AdditionTreeNode;
import interpreter.tree.MultiplicationTreeNode;
import interpreter.tree.UnaryMinusTreeNode;

/**
 * Tree visitor interface
 * 
 * @author Lucja Kot
 */
public interface TreeVisitor {
	void visit(LeafTreeNode node);

	void visit(UnaryMinusTreeNode node);

	void visit(AdditionTreeNode node);

	void visit(MultiplicationTreeNode node);

	void visit(SubtractionTreeNode minusNode);

	void visit(DivisionTreeNode divisionNode);
}
