
import java.util.LinkedList;

public class LexicalAnalyzer {
    
//Types for lexical analyzer to analyze
    static enum Type {
        ADD, SUBTRACT, MULTIPLY, DIVIDE, REMAINDER, OPERAND
    }
    
//Class to hold token type and value
    static class Token<TT, TV> {
        private final TT t;
        private final TV value;
        
        public Token(TT t, TV value) {
            this.t = t;
            this.value = value;
        }
//return token type and value
        @Override
        public String toString() {
            return "Token text: " + this.value + System.getProperty("line.separator") + "Token lexical category: " + this.t;
        }
    }
    
//starts from a specific index and parses all the variables and integers
    private static String getOperand(String operand, int index) {
        int i = index;
        for( ; i < operand.length(); ) {
            if(Character.isLetterOrDigit(operand.charAt(i))) {
                i++;
            }
            else {
                return operand.substring(index, i);
            }
        }
        return operand.substring(index, i);
    }
    
//lexically analyzes the expression
    protected static LinkedList<Token<Type, String>> analyze(String expression) {
        LinkedList<Token<Type, String>> tokens = new LinkedList<>();
        for(int i = 0; i < expression.length(); ) {
            char currentCharacter = expression.charAt(i);
            switch(currentCharacter) {
                case '+':
                    tokens.add(new Token<>(Type.ADD, String.valueOf(currentCharacter)));
                    i++;
                    break;
                case '-':
                    tokens.add(new Token<>(Type.SUBTRACT, String.valueOf(currentCharacter)));
                    i++;
                    break;
                case '*':
                    tokens.add(new Token<>(Type.MULTIPLY, String.valueOf(currentCharacter)));
                    i++;
                    break;
                case '/':
                    tokens.add(new Token<>(Type.DIVIDE, String.valueOf(currentCharacter)));
                    i++;
                    break;
                case '%':
                    tokens.add(new Token<>(Type.REMAINDER, String.valueOf(currentCharacter)));
                    i++;
                    break;
                default:
                    if(Character.isWhitespace(currentCharacter)) {
                        i++;
                    }
                    else {
                        
                        //Get the operand and increment the counter by the operand's length to continue parsing the expression
                        String operand = LexicalAnalyzer.getOperand(expression, i);
                        i += operand.length();
                        tokens.add(new Token<>(Type.OPERAND, operand));
                    }
                    break;
            }
        }
        return tokens;
    }
    
    public static void main(String[] args) {
        LinkedList<Token<Type, String>> tokens = LexicalAnalyzer.analyze(args[0]);
        for(Token token : tokens) {
            System.out.println(token);
        }
    }
}