import java.util.*;
import java.io.*;
class rdp
{
static char inp[]=new char[10]; //static method can call static data
static int index=0;
public static void main(String args[]) throws IOException
{
String input;
int valid;
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter input string");
input=br.readLine();
inp=input.toCharArray();
try
{
valid=E();
if(valid==1)
System.out.println("Input String is valid");
else
System.out.println("Input String is invalid");
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println("Input String is invalid");
}
}
static int E()
{
if(inp[index++]!='x')
return 0;
if(inp[index++]!='+')
return 0;
if(T()==1)
return 1;
else
return 0;
}
static int T()
{
if(inp[index]=='x' || inp[index]=='(')
{
if(inp[index++]=='x')
return 1;
if(inp[index-1]=='(')
{
if(E()==1)
{
if(inp[index++]!=')')
return 0;
else
return 1;
}
else
return 0;
}
else
return 0;
}
else
return 0;
}
}